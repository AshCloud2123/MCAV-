import datetime
import psycopg2
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMessageBox
from datetime import date

class Ui_AddOrder(object):

    def __init__(self):
        # PostgreSQL connection        
        self.conn = psycopg2.connect(host="aws-0-ap-southeast-1.pooler.supabase.com", dbname="postgres", user="postgres.oxzprkjuxnjgnfihweyj", 
                                     password="Milliondollarbaby123", port=6543)
        self.cur = self.conn.cursor()

    def save_data(self):
        cus_code = self.searchLineEdit.text().strip()
        due_date = self.dueDateEdit.date().toString(QtCore.Qt.ISODate)
        product_category = self.comboBox.currentText()
        product_name = self.comboBox_product.currentText()
        quantity = self.QuantityLineEdit.text()
        total_amount = self.TotalLineEdit.text()
        rollsize_width = self.sizeLineEdit1.text()
        rollsize_height = self.sizeLineEdit2.text()
        rollsize = (f'{rollsize_width} X {rollsize_height}')

        # Validate input data
        if not all([cus_code, due_date, product_category, product_name, quantity, total_amount]):
            missing_fields = []
            if not cus_code:
                missing_fields.append("Customer ID")
            if not due_date:
                missing_fields.append("Due Date")
            if not product_category:
                missing_fields.append("Product Category Date")
            if not product_name:
                missing_fields.append("Product Name")
            if not quantity:
                missing_fields.append("Quantity")
            if not total_amount:
                missing_fields.append("Total Amount")

            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText(f"Please input all required fields:\n{', '.join(missing_fields)}")
            msg.setWindowTitle("Required Fields")
            msg.exec_()
            return

        confirm_msg = QMessageBox()
        confirm_msg.setIcon(QMessageBox.Question)
        confirm_msg.setText("Add to Purchase list?")
        confirm_msg.setWindowTitle("Confirmation")
        confirm_msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        
        result = confirm_msg.exec_()

        if result == QMessageBox.Yes:
            try:
                # Fetch product ID based on product name
                sql_get_product_id = "SELECT PROD_ID FROM PRODUCT WHERE PROD_NAME = %s"
                self.cur.execute(sql_get_product_id, (product_name,))
                product_id_result = self.cur.fetchone()

                if product_id_result is None:
                    self.show_message("Error", "Selected product does not exist.")
                    return

                product_id = product_id_result[0]
                
                # Insert into ORDERS table
                sql_orders = """
                INSERT INTO ORDERS (CUS_CODE, ORD_DATE_COMPLETION, PROD_ID, ORD_QUANTITY, ORD_TOTAL_AMOUNT, ORD_SIZE) 
                VALUES (%s, %s, %s, %s, %s, %s)
                """
                self.cur.execute(sql_orders, (cus_code, due_date, product_id, quantity, total_amount, rollsize))

                self.conn.commit()
                self.show_message("Success", "Data saved successfully.")
                self.clear_input_fields()
                
            except psycopg2.Error as e:
                self.conn.rollback()  # Roll back transaction on error
                error_message = f"Error saving data: {e.pgcode} - {e.pgerror}"
                self.show_message("Error", error_message) 

    def clear_input_fields(self):
        self.searchLineEdit.clear()
        self.lineEdit.clear()
        self.lineEdit.clear()
        self.emailLineEdit.clear()
        self.phonelineEdit.clear()
        self.AddressLineEdit.clear()
        self.LnamelineEdit.clear()
        self.TotalLineEdit.clear()
        self.dueDateEdit.setDate(QtCore.QDate())
        self.QuantityLineEdit.clear()

    def set_current_date(self):
        current_date = datetime.date.today()
        qt_date = QtCore.QDate(current_date.year, current_date.month, current_date.day)
        self.dueDateEdit.setDate(qt_date)

    def show_message(self, title, message):
        msg = QMessageBox()
        msg.setWindowTitle(title)
        msg.setText(message)
        msg.setIcon(QMessageBox.Information)
        msg.exec_()

    def search_customer(self):
        cus_code = self.searchLineEdit.text().strip()
        if not cus_code:
            self.show_message("Error", "Please enter a Customer ID to search.")
            return

        try:
            self.cur.execute("SELECT CUS_FNAME, CUS_LNAME, CUS_EMAIL, CUS_PHONE, CUS_ADDRESS FROM CUSTOMER WHERE CUS_CODE = %s", (cus_code,))
            customer_data = self.cur.fetchone()
            if customer_data:
                cus_fname, cus_lname, cus_email, cus_contact, cus_address = customer_data
                self.lineEdit.setText(cus_fname)
                self.LnamelineEdit.setText(cus_lname)
                self.emailLineEdit.setText(cus_email)
                self.phonelineEdit.setText(cus_contact)
                self.AddressLineEdit.setText(cus_address)
            else:
                self.show_message("Not Found", "Customer ID not found.")
        except psycopg2.Error as e:
            error_message = f"Error fetching data: {e.pgcode} - {e.pgerror}"
            self.show_message("Error", error_message)   

    def populate_product_combo_box(self):
        try:
            self.cur.execute("SELECT PROD_NAME FROM PRODUCT")
            product_names = [item[0] for item in self.cur.fetchall()]
            self.comboBox_product.clear()
            self.comboBox_product.addItems(product_names)
        except psycopg2.Error as e:
            error_message = f"Error fetching product names: {e.pgcode} - {e.pgerror}"
            self.show_message("Error", error_message) 

        try:
            self.cur.execute("SELECT CAT_NAME FROM CATEGORY")
            cat_names = [item[0] for item in self.cur.fetchall()]
            self.comboBox.clear()
            self.comboBox.addItems(cat_names)
        except psycopg2.Error as e:
            error_message = f"Error fetching product names: {e.pgcode} - {e.pgerror}"
            self.show_message("Error", error_message) 


    def setupUi(self, AddOrder):
        AddOrder.setObjectName("AddOrder")
        AddOrder.resize(641, 481)
        AddOrder.setFixedSize(640, 480)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        AddOrder.setSizePolicy(sizePolicy)
        self.frame = QtWidgets.QFrame(AddOrder)
        self.frame.setEnabled(True)
        self.frame.setGeometry(QtCore.QRect(0, 0, 641, 481))
        self.frame.setStyleSheet("""
            QFrame {
                background-color: rgb(255, 255, 255);
            }
            QLabel#AddOrder {
                font-size: 25px;
            }
            QLineEdit {
                width: 200px;
            }
            QLineEdit#lineEdit,                      
            QLineEdit#LnamelineEdit, 
            QLineEdit#emailLineEdit, 
            QLineEdit#phonelineEdit,
            QLineEdit#AddressLineEdit {
                background-color: #e3e1e1;
                color: black;
            }
            QPushButton#Cancel {    
                color: rgb(255, 255, 255);
                background-color: #202020;
            }
            QPushButton {    
                color: rgb(255, 255, 255);
                background-color: #CD2E2E;
            }
        """)
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.AddOrder = QtWidgets.QLabel(self.frame)
        self.AddOrder.setGeometry(QtCore.QRect(240, 10, 126, 26))
        self.AddOrder.setObjectName("AddOrder")


        self.searchLineEdit = QtWidgets.QLineEdit(self.frame)
        self.searchLineEdit.setGeometry(QtCore.QRect(80, 80, 111, 20))
        self.searchLineEdit.setObjectName("searchLineEdit")
        self.searchLabel = QtWidgets.QLabel(self.frame)
        self.searchLabel.setGeometry(QtCore.QRect(80, 60, 111, 16))
        self.searchLabel.setObjectName("searchLabel")

        self.searchButton = QtWidgets.QPushButton(self.frame)
        self.searchButton.setGeometry(QtCore.QRect(200, 80, 75, 23))
        self.searchButton.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.searchButton.setObjectName("searchButton")
        font_search = QtGui.QFont()
        font_search.setFamily("Arial")
        font_search.setPointSize(8)
        font_search.setBold(True)
        self.searchButton.setFont(font_search)
        self.searchButton.clicked.connect(self.search_customer) 

        self.Cancel = QtWidgets.QPushButton(self.frame)
        self.Cancel.clicked.connect(AddOrder.close)
        self.Cancel.setGeometry(QtCore.QRect(380, 370, 96, 31))
        self.Cancel.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Cancel.setObjectName("Cancel")
        font_cancel = QtGui.QFont()
        font_cancel.setFamily("Arial")
        font_cancel.setPointSize(10)
        font_cancel.setBold(True)        
        self.Cancel.setFont(font_cancel)
        self.AddOrder_3 = QtWidgets.QPushButton(self.frame)
        self.AddOrder_3.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.AddOrder_3.clicked.connect(self.save_data)
        self.AddOrder_3.setGeometry(QtCore.QRect(490, 370, 91, 31))
        self.AddOrder_3.setObjectName("AddOrder_3")
        font_AddOrder_3 = QtGui.QFont()
        font_AddOrder_3.setFamily("Arial")
        font_AddOrder_3.setPointSize(10)
        font_AddOrder_3.setBold(True)        
        self.AddOrder_3.setFont(font_cancel)
        
        self.frame_2 = QtWidgets.QFrame(self.frame)
        self.frame_2.setGeometry(QtCore.QRect(50, 50, 521, 361))
        self.frame_2.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.frame_2.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.frame_2.setLineWidth(1)
        self.frame_2.setObjectName("frame_2")
        self.Cancel.raise_()
        self.AddOrder_3.raise_()

        self.lineEdit = QtWidgets.QLineEdit(self.frame_2)
        self.lineEdit.setGeometry(QtCore.QRect(30, 80, 111, 20))
        self.lineEdit.setMaxLength(300)
        self.lineEdit.setObjectName("lineEdit")
        self.label = QtWidgets.QLabel(self.frame_2)
        self.label.setGeometry(QtCore.QRect(30, 60, 101, 16))
        self.label.setObjectName("label")
        self.lineEdit.setReadOnly(True)

        self.LnamelineEdit = QtWidgets.QLineEdit(self.frame_2)
        self.LnamelineEdit.setGeometry(QtCore.QRect(30, 130, 111, 20))
        self.LnamelineEdit.setMaxLength(300)
        self.LnamelineEdit.setObjectName("LnamelineEdit")
        self.lnameLabel = QtWidgets.QLabel(self.frame_2)
        self.lnameLabel.setGeometry(QtCore.QRect(30, 110, 101, 16))
        self.lnameLabel.setObjectName("lnameLabel")
        self.LnamelineEdit.setReadOnly(True)

        self.emailLineEdit = QtWidgets.QLineEdit(self.frame_2)
        self.emailLineEdit.setGeometry(QtCore.QRect(30, 180, 113, 20))
        self.emailLineEdit.setObjectName("emailLineEdit")
        self.emailLabel = QtWidgets.QLabel(self.frame_2)
        self.emailLabel.setGeometry(QtCore.QRect(30, 160, 76, 16))
        self.emailLabel.setObjectName("emailLabel")
        self.emailLineEdit.setReadOnly(True)

        self.phonelineEdit = QtWidgets.QLineEdit(self.frame_2)
        self.phonelineEdit.setGeometry(QtCore.QRect(30, 230, 113, 20))
        self.phonelineEdit.setObjectName("phonelineEdit")
        self.phoneLineLabel = QtWidgets.QLabel(self.frame_2)
        self.phoneLineLabel.setGeometry(QtCore.QRect(30, 210, 81, 16))
        self.phoneLineLabel.setObjectName("phoneLineLabel")
        self.phonelineEdit.setReadOnly(True)

        self.AddressLineEdit = QtWidgets.QLineEdit(self.frame_2)
        self.AddressLineEdit.setGeometry(QtCore.QRect(30, 280, 113, 20))
        self.AddressLineEdit.setObjectName("AddressLineEdit")
        self.addressLabel = QtWidgets.QLabel(self.frame_2)
        self.addressLabel.setGeometry(QtCore.QRect(30, 260, 76, 16))
        self.addressLabel.setObjectName("addressLabel")
        self.AddressLineEdit.setReadOnly(True)

        self.TotalLineEdit = QtWidgets.QLineEdit(self.frame_2)
        self.TotalLineEdit.setGeometry(QtCore.QRect(330, 280, 113, 20))
        self.TotalLineEdit.setObjectName("TotalLineEdit")
        self.totalAmtLabel = QtWidgets.QLabel(self.frame_2)
        self.totalAmtLabel.setGeometry(QtCore.QRect(330, 260, 76, 16))
        self.totalAmtLabel.setObjectName("totalAmtLabel")

        self.dueDateEdit = QtWidgets.QDateEdit(self.frame_2)
        self.dueDateEdit.setGeometry(QtCore.QRect(330, 30, 113, 22))
        self.dueDateEdit.setCalendarPopup(True)
        self.dueDateEdit.setObjectName("dueDateEdit")
        self.dueDateEdit.setDate(QtCore.QDate.currentDate())  

        self.dueDateLabel = QtWidgets.QLabel(self.frame_2)
        self.dueDateLabel.setGeometry(QtCore.QRect(330, 10, 47, 14))
        self.dueDateLabel.setObjectName("dueDateLabel")
        self.dueDateLabel.setText("Due Date") 


        self.comboBox = QtWidgets.QComboBox(self.frame_2)
        self.comboBox.setGeometry(QtCore.QRect(330, 80, 151, 22))
        self.comboBox.setObjectName("comboBox")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.categoryLabel = QtWidgets.QLabel(self.frame_2)
        self.categoryLabel.setGeometry(QtCore.QRect(330, 60, 81, 16))
        self.categoryLabel.setObjectName("categoryLabel")

        self.comboBox_product = QtWidgets.QComboBox(self.frame_2)
        self.comboBox_product.setGeometry(QtCore.QRect(330, 130, 151, 22))
        self.comboBox_product.setObjectName("comboBox_product")
        self.comboBox_product.addItem("")
        self.comboBox_product.addItem("")
        self.comboBox_product.addItem("")
        self.comboBox_product.addItem("")
        self.productLabel = QtWidgets.QLabel(self.frame_2)
        self.productLabel.setGeometry(QtCore.QRect(330, 110, 81, 16))
        self.productLabel.setObjectName("productLabel")

        self.QuantityLineEdit = QtWidgets.QLineEdit(self.frame_2)
        self.QuantityLineEdit.setGeometry(QtCore.QRect(330, 180, 113, 20))
        self.QuantityLineEdit.setObjectName("QuantityLineEdit")
        self.quantityLabel = QtWidgets.QLabel(self.frame_2)
        self.quantityLabel.setGeometry(QtCore.QRect(330, 160, 47, 14))
        self.quantityLabel.setObjectName("quantityLabel")

        self.sizeLineEdit1 = QtWidgets.QLineEdit(self.frame_2)
        self.sizeLineEdit1.setGeometry(QtCore.QRect(330, 230, 41, 20))
        self.sizeLineEdit1.setObjectName("sizeLineEdit1")
        self.sizeLabel = QtWidgets.QLabel(self.frame_2)
        self.sizeLabel.setGeometry(QtCore.QRect(330, 210, 47, 14))
        self.sizeLabel.setObjectName("sizeLabel")

        self.sizeLineEdit2 = QtWidgets.QLineEdit(self.frame_2)
        self.sizeLineEdit2.setGeometry(QtCore.QRect(400, 230, 41, 20))
        self.sizeLineEdit2.setObjectName("sizeLineEdit2")

        self.textEdit = QtWidgets.QTextEdit(self.frame_2)
        self.textEdit.setEnabled(True)
        self.textEdit.setGeometry(QtCore.QRect(378, 230, 21, 41))
        self.textEdit.setAcceptDrops(False)
        self.textEdit.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.textEdit.setAcceptRichText(False)
        self.textEdit.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        self.textEdit.setObjectName("textEdit")

        self.searchButton.raise_()
        self.searchLabel.raise_()
        self.searchLineEdit.raise_()
        self.totalAmtLabel.raise_()

        AddOrder.setTabOrder(self.searchLineEdit, self.searchButton)
        AddOrder.setTabOrder(self.searchButton, self.lineEdit)
        AddOrder.setTabOrder(self.lineEdit, self.LnamelineEdit)
        AddOrder.setTabOrder(self.LnamelineEdit, self.emailLineEdit)
        AddOrder.setTabOrder(self.emailLineEdit, self.phonelineEdit)
        AddOrder.setTabOrder(self.phonelineEdit, self.AddressLineEdit)
        AddOrder.setTabOrder(self.AddressLineEdit, self.TotalLineEdit)
        AddOrder.setTabOrder(self.TotalLineEdit, self.dueDateEdit)
        AddOrder.setTabOrder(self.dueDateEdit, self.comboBox)
        AddOrder.setTabOrder(self.comboBox, self.comboBox_product)
        AddOrder.setTabOrder(self.comboBox_product, self.QuantityLineEdit)
        AddOrder.setTabOrder(self.QuantityLineEdit, self.sizeLineEdit1)
        AddOrder.setTabOrder(self.sizeLineEdit1, self.sizeLineEdit2)
        AddOrder.setTabOrder(self.sizeLineEdit2, self.AddOrder_3)
        AddOrder.setTabOrder(self.AddOrder_3, self.Cancel)

        self.retranslateUi(AddOrder)
        QtCore.QMetaObject.connectSlotsByName(AddOrder)

    def retranslateUi(self, AddOrder):
        _translate = QtCore.QCoreApplication.translate
        AddOrder.setWindowTitle(_translate("AddOrder", "Dialog"))
        self.AddOrder.setText(_translate("AddOrder", "Add Order"))
        self.searchLabel.setText(_translate("AddOrder", "Search Customer ID"))
        self.searchButton.setText(_translate("AddOrder", "Search"))
        self.Cancel.setText(_translate("AddOrder", "Cancel"))
        self.AddOrder_3.setText(_translate("AddOrder", "Add Order"))
        self.addressLabel.setText(_translate("AddOrder", "Address"))
        self.sizeLabel.setText(_translate("AddOrder", "Size"))
        self.quantityLabel.setText(_translate("AddOrder", "Quantity"))
        self.categoryLabel.setText(_translate("AddOrder", "Category"))
        self.productLabel.setText(_translate("AddOrder", "Product Name"))
        self.dueDateLabel.setText(_translate("AddOrder", "Due Date"))
        self.phoneLineLabel.setText(_translate("AddOrder", "Contact Number"))
        self.label.setText(_translate("AddOrder", "Customer First Name"))
        self.lnameLabel.setText(_translate("AddOrder", "Customer Last Name"))
        self.emailLabel.setText(_translate("AddOrder", "Email Address"))
        self.totalAmtLabel.setText(_translate("AddOrder", "Total Amount"))
        self.textEdit.setHtml(_translate("AddOrder", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                                "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                                "p, li { white-space: pre-wrap; }\n"
                                                "</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
                                                "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-weight:600;\">X</span></p></body></html>"))
        self.populate_product_combo_box()
if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    AddOrder = QtWidgets.QDialog()
    ui = Ui_AddOrder()
    ui.setupUi(AddOrder)
    AddOrder.show()
    sys.exit(app.exec_())
